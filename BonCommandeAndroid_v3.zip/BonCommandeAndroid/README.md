# BonCommandeAndroid — V1

Application Android native (Jetpack Compose) pour saisir un bon de commande.

### Inclus
- D.LV automatique
- Date automatique
- Client / téléphone / CIN / adresse
- 8 lignes
- Nom du produit et prix saisis manuellement
- Calcul quantité × prix, total, avance et reste
- Conditions de vente
- Génération d'un PDF A4
- Partage du PDF (WhatsApp peut être choisi dans le menu Android)

### Ouvrir
Avec Android Studio : ouvrir ce dossier, synchroniser Gradle puis lancer sur un appareil Android.

### À compléter en V2
- Logo réel et QR code Facebook
- Signature tactile réellement enregistrée dans le PDF
- Historique/recherche des bons
- Impression optimisée à l'identique de la photo
