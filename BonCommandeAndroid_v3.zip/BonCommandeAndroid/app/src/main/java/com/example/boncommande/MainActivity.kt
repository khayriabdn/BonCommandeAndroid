package com.example.boncommande

import android.content.Context
import android.content.Intent
import android.graphics.Bitmap
import android.graphics.Canvas as ACanvas
import android.graphics.Paint
import android.graphics.pdf.PdfDocument
import android.os.Bundle
import android.os.Environment
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.gestures.detectDragGestures
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.asAndroidPath
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.foundation.Image
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.content.FileProvider
import com.google.zxing.BarcodeFormat
import com.google.zxing.MultiFormatWriter
import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import java.io.FileOutputStream
import java.text.SimpleDateFormat
import java.util.*

private val LightBlue = Color(0xFFDDF5FA)
data class LineItem(var qty:String="", var designation:String="", var unit:String="")
data class SavedBon(val dlv:String,val client:String,val tel:String,val cin:String,val adresse:String,val date:String,val avance:String,val items:List<LineItem>,val seller:Strokes=mutableListOf(),val customer:Strokes=mutableListOf())

typealias Strokes = MutableList<MutableList<Offset>>

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) { super.onCreate(savedInstanceState); setContent { BonCommandeApp(this) } }
}

@Composable fun BonCommandeApp(context: Context) {
    var dlv by remember { mutableStateOf(nextDlv(context)) }
    var client by remember { mutableStateOf("") }; var tel by remember { mutableStateOf("") }
    var cin by remember { mutableStateOf("") }; var adresse by remember { mutableStateOf("") }
    var date by remember { mutableStateOf(today()) }; var avance by remember { mutableStateOf("") }
    val items = remember { mutableStateListOf<LineItem>().apply { repeat(8){add(LineItem())} } }
    val seller = remember { mutableStateListOf<MutableList<Offset>>() }
    val customer = remember { mutableStateListOf<MutableList<Offset>>() }
    var facebook by remember { mutableStateOf(loadFacebook(context)) }
    var showSaved by remember { mutableStateOf(false) }
    val total = items.sumOf { (it.qty.toDoubleOrNull()?:0.0)*(it.unit.toDoubleOrNull()?:0.0) }
    val reste = total-(avance.toDoubleOrNull()?:0.0)

    MaterialTheme { Scaffold(topBar={TopAppBar(title={Text("BON DE COMMANDE",fontWeight=FontWeight.Bold)}, actions={Text("D.LV $dlv",Modifier.padding(end=12.dp),fontSize=13.sp)})}) { pad ->
        Column(Modifier.padding(pad).verticalScroll(rememberScrollState()).padding(12.dp)) {
            Text("Logo / Facebook",fontWeight=FontWeight.Bold,fontSize=18.sp)
            Row(verticalAlignment=Alignment.CenterVertically) {
                Image(painter=androidx.compose.ui.res.painterResource(com.example.boncommande.R.drawable.company_logo),contentDescription="Logo",modifier=Modifier.size(92.dp))
                Spacer(Modifier.width(10.dp))
                Image(painter=androidx.compose.ui.res.painterResource(com.example.boncommande.R.drawable.facebook_qr),contentDescription="QR Facebook",modifier=Modifier.size(78.dp))
                Spacer(Modifier.width(10.dp)); Column(Modifier.weight(1f)){
                    Text("Tél: 52 09 09 42",fontWeight=FontWeight.Bold,fontSize=12.sp)
                    Text("Rue Gabes-Tunisie KM2",fontSize=11.sp)
                    Text("QR Facebook intégré",fontSize=11.sp)
                }
            }
            Spacer(Modifier.height(10.dp)); Text("Informations client",fontWeight=FontWeight.Bold,fontSize=18.sp)
            Field("D.LV",dlv,{},enabled=false); Field("Client",client,{client=it}); Field("Tél",tel,{tel=it},KeyboardType.Phone); Field("CIN",cin,{cin=it},KeyboardType.Number); Field("Adresse",adresse,{adresse=it}); Field("Le",date,{date=it})
            Spacer(Modifier.height(10.dp)); Text("Produits",fontWeight=FontWeight.Bold,fontSize=18.sp)
            Row(Modifier.fillMaxWidth().background(LightBlue).border(1.dp,Color.Black).padding(5.dp)){ Header("Qté",.12f);Header("Désignation",.48f);Header("Mont U",.18f);Header("Mont TT",.22f)}
            items.forEach { item -> Row(Modifier.fillMaxWidth().heightIn(min=54.dp).border(1.dp,Color.Black)){ CellField(item.qty,{item.qty=it},.12f,KeyboardType.Decimal);CellField(item.designation,{item.designation=it},.48f);CellField(item.unit,{item.unit=it},.18f,KeyboardType.Decimal); val line=(item.qty.toDoubleOrNull()?:0.0)*(item.unit.toDoubleOrNull()?:0.0);Box(Modifier.weight(.22f).fillMaxHeight().padding(6.dp),contentAlignment=Alignment.CenterEnd){Text(if(line==0.0)"-" else money(line))} } }
            Text("TOTAL : ${money(total)} dt",fontWeight=FontWeight.Bold,fontSize=18.sp,modifier=Modifier.fillMaxWidth().padding(8.dp),textAlign=androidx.compose.ui.text.style.TextAlign.End)
            Field("Avance (dt)",avance,{avance=it},KeyboardType.Decimal); Text("Reste : ${money(reste)} dt",fontWeight=FontWeight.Bold,fontSize=18.sp,modifier=Modifier.fillMaxWidth().padding(8.dp),textAlign=androidx.compose.ui.text.style.TextAlign.End)
            Text("Signatures",fontWeight=FontWeight.Bold,fontSize=18.sp); Row(Modifier.fillMaxWidth(),horizontalArrangement=Arrangement.spacedBy(10.dp)){ SignatureBox("Vendeur",seller);SignatureBox("Client",customer) }
            Spacer(Modifier.height(8.dp)); Text("Conditions de vente",fontWeight=FontWeight.Bold); Text(conditions(),fontSize=11.sp)
            Row(Modifier.fillMaxWidth(),horizontalArrangement=Arrangement.spacedBy(8.dp)){ Button(onClick={saveBon(context, SavedBon(dlv,client,tel,cin,adresse,date,avance,items.map{it.copy()},seller.map{it.toMutableList()}.toMutableList(),customer.map{it.toMutableList()}.toMutableList()));Toast.makeText(context,"Bon sauvegardé",Toast.LENGTH_SHORT).show()},Modifier.weight(1f)){Text("💾 Sauver")}; Button(onClick={showSaved=true},Modifier.weight(1f)){Text("📁 Bons")}}
            Row(Modifier.fillMaxWidth(),horizontalArrangement=Arrangement.spacedBy(8.dp)){ Button(onClick={resetForm(context,items).also{dlv=nextDlv(context);client="";tel="";cin="";adresse="";avance="";date=today();seller.clear();customer.clear()}},Modifier.weight(1f)){Text("Nouveau")}; Button(onClick={val f=createPdf(context,dlv,client,tel,cin,adresse,date,avance,items.toList(),total,reste,seller,customer,facebook);sharePdf(context,f)},Modifier.weight(1f)){Text("PDF / Partager")}}
            Spacer(Modifier.height(20.dp))
        }
        if(showSaved) SavedDialog(context,{showSaved=false},{b-> dlv=b.dlv;client=b.client;tel=b.tel;cin=b.cin;adresse=b.adresse;date=b.date;avance=b.avance;items.clear();items.addAll(b.items.map{it.copy()});seller.clear();seller.addAll(b.seller.map{it.toMutableList()});customer.clear();customer.addAll(b.customer.map{it.toMutableList()});showSaved=false})
    }}
}

@Composable fun SignatureBox(title:String, strokes:Strokes){ Column(Modifier.weight(1f)){ Text(title,fontWeight=FontWeight.Bold,modifier=Modifier.align(Alignment.CenterHorizontally)); Box(Modifier.fillMaxWidth().height(120.dp).border(1.dp,Color.DarkGray)){ Canvas(Modifier.fillMaxSize().pointerInput(Unit){detectDragGestures(onDragStart={p->strokes.add(mutableListOf(p))},onDrag={change,_->strokes.lastOrNull()?.add(change.position);change.consume()},onDragEnd={})}){ strokes.forEach{s-> if(s.size>1){val path=Path().apply{moveTo(s[0].x,s[0].y);for(i in 1 until s.size)lineTo(s[i].x,s[i].y)};drawPath(path,Color.Black,style=androidx.compose.ui.graphics.drawscope.Stroke(width=3f))}} } }; TextButton(onClick={strokes.clear()}){Text("Effacer")} } }
@Composable fun Field(label:String,value:String,onChange:(String)->Unit,type:KeyboardType=KeyboardType.Text,enabled:Boolean=true){OutlinedTextField(value,onChange,label={Text(label)},singleLine=true,enabled=enabled,keyboardOptions=KeyboardOptions(keyboardType=type),modifier=Modifier.fillMaxWidth().padding(vertical=3.dp))}
@Composable fun Header(t:String,w:Float){Box(Modifier.weight(w),contentAlignment=Alignment.Center){Text(t,fontWeight=FontWeight.Bold,fontSize=13.sp)}}
@Composable fun CellField(v:String,on:(String)->Unit,w:Float,type:KeyboardType=KeyboardType.Text){OutlinedTextField(v,on,singleLine=true,keyboardOptions=KeyboardOptions(keyboardType=type),modifier=Modifier.weight(w).fillMaxHeight().padding(2.dp),textStyle=LocalTextStyle.current.copy(fontSize=12.sp))}

@Composable fun SavedDialog(context:Context,onClose:()->Unit,onLoad:(SavedBon)->Unit){ val list=loadBons(context); AlertDialog(onDismissRequest=onClose,title={Text("Bons sauvegardés")},text={Column(Modifier.heightIn(max=400.dp).verticalScroll(rememberScrollState())){if(list.isEmpty())Text("Aucun bon sauvegardé") else list.reversed().forEach{b->Row(Modifier.fillMaxWidth().padding(6.dp),verticalAlignment=Alignment.CenterVertically){Column(Modifier.weight(1f)){Text("D.LV ${b.dlv}",fontWeight=FontWeight.Bold);Text(b.client);Text(b.date,fontSize=12.sp)};Button(onClick={onLoad(b)}){Text("Ouvrir")}}}}},confirmButton={TextButton(onClick=onClose){Text("Fermer")}})}

fun today()=SimpleDateFormat("dd/MM/yyyy",Locale.FRANCE).format(Date())
fun money(v:Double)=if(v==v.toLong().toDouble())v.toLong().toString() else String.format(Locale.US,"%.3f",v)
fun nextDlv(c:Context):String{val p=c.getSharedPreferences("bon",0);val n=p.getInt("n",0)+1;p.edit().putInt("n",n).apply();return n.toString().padStart(4,'0')}
fun resetForm(c:Context,items:MutableList<LineItem>){items.forEach{it.qty="";it.designation="";it.unit=""}}
fun saveFacebook(c:Context,u:String){c.getSharedPreferences("settings",0).edit().putString("facebook",u).apply()}
fun loadFacebook(c:Context)=c.getSharedPreferences("settings",0).getString("facebook","")?:""
fun strokesToJson(strokes:Strokes):JSONArray=JSONArray().apply{strokes.forEach{s->put(JSONArray().apply{s.forEach{p->put(JSONArray().apply{put(p.x);put(p.y)})}})}}
fun jsonToStrokes(a:JSONArray):Strokes=mutableListOf<MutableList<Offset>>().apply{for(i in 0 until a.length()){val sa=a.getJSONArray(i);add(mutableListOf<Offset>().apply{for(j in 0 until sa.length()){val p=sa.getJSONArray(j);add(Offset(p.getDouble(0).toFloat(),p.getDouble(1).toFloat()))}})}}
fun saveBon(c:Context,b:SavedBon){val a=JSONArray(c.getSharedPreferences("bons",0).getString("list","[]"));a.put(JSONObject().apply{put("dlv",b.dlv);put("client",b.client);put("tel",b.tel);put("cin",b.cin);put("adresse",b.adresse);put("date",b.date);put("avance",b.avance);put("seller",strokesToJson(b.seller));put("customer",strokesToJson(b.customer));put("items",JSONArray().apply{b.items.forEach{put(JSONObject().apply{put("qty",it.qty);put("designation",it.designation);put("unit",it.unit)})}})});c.getSharedPreferences("bons",0).edit().putString("list",a.toString()).apply()}
fun loadBons(c:Context):List<SavedBon>{val a=JSONArray(c.getSharedPreferences("bons",0).getString("list","[]"));return buildList{for(i in 0 until a.length()){val o=a.getJSONObject(i);val ia=o.getJSONArray("items");val ss=o.optJSONArray("seller")?:JSONArray();val cs=o.optJSONArray("customer")?:JSONArray();add(SavedBon(o.getString("dlv"),o.getString("client"),o.getString("tel"),o.getString("cin"),o.getString("adresse"),o.getString("date"),o.getString("avance"),buildList{for(j in 0 until ia.length()){val x=ia.getJSONObject(j);add(LineItem(x.getString("qty"),x.getString("designation"),x.getString("unit")))}},jsonToStrokes(ss),jsonToStrokes(cs)))}}}
fun qrBitmap(text:String,size:Int=150):Bitmap?{if(text.isBlank())return null;return try{val matrix=MultiFormatWriter().encode(text,BarcodeFormat.QR_CODE,size,size);Bitmap.createBitmap(size,size,Bitmap.Config.ARGB_8888).also{for(x in 0 until size)for(y in 0 until size)it.setPixel(x,y,if(matrix[x,y])android.graphics.Color.BLACK else android.graphics.Color.WHITE)}}catch(_:Exception){null}}
fun createPdf(c:Context,dlv:String,client:String,tel:String,cin:String,adresse:String,date:String,avance:String,items:List<LineItem>,total:Double,reste:Double,seller:Strokes,customer:Strokes,facebook:String):File{
    val doc=PdfDocument();val page=doc.startPage(PdfDocument.PageInfo.Builder(595,842,1).create());val canvas=page.canvas;val p=Paint().apply{color=android.graphics.Color.BLACK;textSize=9f}
    p.typeface=android.graphics.Typeface.DEFAULT_BOLD;p.textSize=17f;canvas.drawText("BON DE COMMANDE",145f,45f,p);p.typeface=android.graphics.Typeface.DEFAULT;p.textSize=9f
    canvas.drawText("D.LV : $dlv",25f,80f,p);canvas.drawText("Tél: 52 09 09 42",390f,25f,p);canvas.drawText("Rue Gabes-Tunisie KM2",370f,40f,p);canvas.drawText("QR code page Facebook",350f,53f,p)
    val logo=android.graphics.BitmapFactory.decodeResource(c.resources,com.example.boncommande.R.drawable.company_logo)
    if(logo!=null) canvas.drawBitmap(logo,null,android.graphics.RectF(18f,18f,105f,72f),p)
    canvas.drawText("Client : $client",65f,105f,p);canvas.drawText("Tél : $tel",65f,125f,p);canvas.drawText("CIN : $cin",65f,145f,p);canvas.drawText("Adresse : $adresse",65f,165f,p);canvas.drawText("Le : $date",390f,105f,p);canvas.drawText("Avance : $avance dt",390f,125f,p);canvas.drawText("Reste : ${money(reste)} dt",390f,145f,p)
    val x=intArrayOf(45,105,370,455,555);var y=190;p.style=Paint.Style.STROKE;canvas.drawRect(45f,y.toFloat(),555f,(y+25).toFloat(),p);for(xx in x.drop(1))canvas.drawLine(xx.toFloat(),y.toFloat(),xx.toFloat(),(y+25+8*35).toFloat(),p);p.style=Paint.Style.FILL;p.typeface=android.graphics.Typeface.DEFAULT_BOLD;canvas.drawText("Qté",60f,(y+17).toFloat(),p);canvas.drawText("Désignation",200f,(y+17).toFloat(),p);canvas.drawText("Mont U",390f,(y+17).toFloat(),p);canvas.drawText("Mont TT",480f,(y+17).toFloat(),p);p.typeface=android.graphics.Typeface.DEFAULT;y+=25
    items.forEach{canvas.drawRect(45f,y.toFloat(),555f,(y+35).toFloat(),p);canvas.drawText(it.qty,60f,(y+22).toFloat(),p);canvas.drawText(it.designation.take(38),110f,(y+22).toFloat(),p);canvas.drawText(it.unit,380f,(y+22).toFloat(),p);val line=(it.qty.toDoubleOrNull()?:0.0)*(it.unit.toDoubleOrNull()?:0.0);canvas.drawText(if(line==0.0)"-" else money(line),475f,(y+22).toFloat(),p);y+=35}
    p.typeface=android.graphics.Typeface.DEFAULT_BOLD;canvas.drawText("TOTAL : ${money(total)} dt",420f,(y+25).toFloat(),p);y+=60;p.typeface=android.graphics.Typeface.DEFAULT;canvas.drawText("signature de vendeur",70f,y.toFloat(),p);canvas.drawText("signature de client",400f,y.toFloat(),p);p.style=Paint.Style.STROKE;canvas.drawRect(45f,(y+10).toFloat(),250f,(y+100).toFloat(),p);canvas.drawRect(345f,(y+10).toFloat(),550f,(y+100).toFloat(),p);p.style=Paint.Style.FILL
    drawStrokes(canvas,seller,45f,y+10f,205f,90f);drawStrokes(canvas,customer,345f,y+10f,205f,90f)
    val qr=android.graphics.BitmapFactory.decodeResource(c.resources,com.example.boncommande.R.drawable.facebook_qr)
    if(qr!=null) canvas.drawBitmap(qr,null,android.graphics.RectF(475f,18f,555f,98f),p)
    y+=130;p.typeface=android.graphics.Typeface.DEFAULT_BOLD;canvas.drawText("condition de vente",220f,y.toFloat(),p);p.typeface=android.graphics.Typeface.DEFAULT;y+=18;conditions().split("\n").forEach{line->if(y<820){canvas.drawText(line.take(100),25f,y.toFloat(),p);y+=11}}
    doc.finishPage(page);val dir=c.getExternalFilesDir(Environment.DIRECTORY_DOCUMENTS)!!;val f=File(dir,"Bon_$dlv.pdf");FileOutputStream(f).use{doc.writeTo(it)};doc.close();return f
}
fun drawStrokes(canvas:ACanvas,strokes:Strokes,x:Float,y:Float,w:Float,h:Float){val p=Paint().apply{color=android.graphics.Color.BLACK;style=Paint.Style.STROKE;strokeWidth=2f};strokes.forEach{s->if(s.size>1){val path=android.graphics.Path();path.moveTo(x+s[0].x,y+s[0].y);for(i in 1 until s.size)path.lineTo(x+s[i].x,y+s[i].y);canvas.drawPath(path,p)}}}
fun sharePdf(c:Context,f:File){val uri=FileProvider.getUriForFile(c,c.packageName+".provider",f);val i=Intent(Intent.ACTION_SEND).apply{type="application/pdf";putExtra(Intent.EXTRA_STREAM,uri);addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)};c.startActivity(Intent.createChooser(i,"Partager le bon"))}
fun conditions()="1/ À la commande, le client verse 30% du prix à titre d'arrhes, en cas d'annulation de la commande, les arrhes sont retenues définitivement à titre de dommage et intérêts (Art.305 COC).\n\n2/ Les prix figurant à la commande sont révisables et les livraisons sont toujours facturées aux prix en vigueur à la date de livraison.\n\n3/ Les meubles demeurent notre propriété jusqu'au paiement intégral du prix. Dès qu'ils sont livrés, ils sont sous la responsabilité et aux risques et périls du client.\n\n4/ En cas où le client a payé par chèque ou lettre de change daté, interdite de changer l'adresse avant le paiement complet du chèque ou lettre de change.\n\n5/ En cas où le paiement de chèque ou lettre de change sont impayés, tous les litiges, quelque soit la nature, seront soumis aux tribunaux et les meubles seront rendu sans les arrhes.\n\n6/ Après la lecture de toute les conditions de ventes, je soussigné que j'accepte tous ses conditions, avec la signature et le numéro du CIN."
